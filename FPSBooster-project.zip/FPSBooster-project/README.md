# FPSBooster

Starter source bundle for the Java NeoForge and Bedrock editions.

- `java/` is the NeoForge 26.3 Gradle project.
- `bedrock/` is a Bedrock behavior pack source folder.
- GitHub Actions can unzip this bundle and build/package both outputs.

Important: Bedrock scripting cannot read the device's actual FPS, RAM, or CPU usage.
The starter Bedrock pack therefore reports only supported in-game information.
The Java project is a buildable starting point; performance optimizations and the
full monitoring HUD will be added and tested in later iterations.
