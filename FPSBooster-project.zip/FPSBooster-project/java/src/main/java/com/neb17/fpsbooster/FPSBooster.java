package com.neb17.fpsbooster;

import net.neoforged.fml.common.Mod;

@Mod(FPSBooster.MOD_ID)
public final class FPSBooster {
    public static final String MOD_ID = "fpsbooster";

    public FPSBooster() {
        // Main mod entry point. Client HUD and safe optimization features
        // will be added in the next build iteration.
    }
}
