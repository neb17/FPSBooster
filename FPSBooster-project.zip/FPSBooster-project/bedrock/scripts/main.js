import { world, system } from "@minecraft/server";

let ticks = 0;

system.runInterval(() => {
  ticks++;
  for (const player of world.getPlayers()) {
    const p = player.location;
    player.onScreenDisplay.setActionBar(
      `§aFPSBooster §7| §fXYZ: ${Math.floor(p.x)}, ${Math.floor(p.y)}, ${Math.floor(p.z)}`
    );
  }
}, 20);
